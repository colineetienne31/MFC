import numpy as np
import matplotlib.pyplot as plt

N    = np.array([1056, 2040, 5088, 9900, 19928, 40200 ])   # cell counts
mean = np.array([2.133456e-03, 6.968430e-04,  3.000531e-04,  1.426872e-04, 7.605628e-05, 3.797975e-05])   # mean errors
mx   = np.array([1.435547e-01, 7.070209e-02,  4.632537e-02,  3.043808e-02, 2.307411e-02, 1.599912e-02])   # max errors

h = np.sqrt(36.0 / N)

p_mean = np.polyfit(np.log(h), np.log(mean), 1)[0]
p_max  = np.polyfit(np.log(h), np.log(mx), 1)[0]

plt.loglog(h, mean, 'o-', label=f'Mean error (order {p_mean:.2f})')
plt.loglog(h, mx,   's-', label=f'Max error (order {p_max:.2f})')
plt.loglog(h, h**2 * mean[0]/h[0]**2, 'k--', label='2nd order')
plt.loglog(h, h    * mean[0]/h[0],    'k:',  label='1st order')
plt.xlabel('h = sqrt(A/N) [m]')
plt.ylabel('Error [K]')
plt.legend(); plt.grid(True, which='both')
plt.savefig('task2_convergence.png', dpi=200)
print(p_mean, p_max)